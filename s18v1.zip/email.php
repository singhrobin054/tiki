<?php
$emailku = 'youremail@gmail.com'; // GANTI EMAIL KAMU DISINI
?>